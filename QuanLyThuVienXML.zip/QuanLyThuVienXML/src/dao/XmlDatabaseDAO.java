package dao;

import entity.*;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class XmlDatabaseDAO {
    private static final String DATA_DIR = "data";
    private static final String FILE_SACH = DATA_DIR + File.separator + "sach.xml";
    private static final String FILE_DOC_GIA = DATA_DIR + File.separator + "docgia.xml";
    private static final String FILE_PHIEU_MUON = DATA_DIR + File.separator + "phieumuon.xml";
    private static final SimpleDateFormat SDF = new SimpleDateFormat("dd/MM/yyyy");

    public XmlDatabaseDAO() {
        File dir = new File(DATA_DIR);
        if (!dir.exists()) dir.mkdirs();
    }

    private Document taoDocumentMoi() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        return builder.newDocument();
    }

    private void ghiFileXml(Document doc, String filePath) throws Exception {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
        transformer.transform(new DOMSource(doc), new StreamResult(new File(filePath)));
    }

    private Element taoElementText(Document doc, String tagName, String value) {
        Element el = doc.createElement(tagName);
        el.appendChild(doc.createTextNode(value != null ? value : ""));
        return el;
    }

    private String layTextTag(Element parent, String tagName) {
        NodeList list = parent.getElementsByTagName(tagName);
        if (list.getLength() > 0 && list.item(0).getFirstChild() != null) {
            return list.item(0).getTextContent().trim();
        }
        return "";
    }

    public void luuDanhSachSach(List<Sach> dsSach) {
        try {
            Document doc = taoDocumentMoi();
            Element root = doc.createElement("DanhSachSach");
            doc.appendChild(root);

            for (Sach s : dsSach) {
                Element node = doc.createElement("Sach");
                node.setAttribute("maSach", String.valueOf(s.getMaSach()));
                node.appendChild(taoElementText(doc, "tenSach", s.getTenSach()));
                node.appendChild(taoElementText(doc, "theLoai", s.getTheLoai()));
                node.appendChild(taoElementText(doc, "nhaXuatBan", s.getNhaXuatBan()));
                node.appendChild(taoElementText(doc, "giaBia", String.valueOf(s.getGiaBia())));
                node.appendChild(taoElementText(doc, "dangMuon", String.valueOf(s.isDangMuon())));
                root.appendChild(node);
            }
            ghiFileXml(doc, FILE_SACH);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Sach> docDanhSachSach() {
        List<Sach> list = new ArrayList<>();
        File file = new File(FILE_SACH);
        if (!file.exists()) return list;
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
            doc.getDocumentElement().normalize();
            NodeList nodes = doc.getElementsByTagName("Sach");
            for (int i = 0; i < nodes.getLength(); i++) {
                Element el = (Element) nodes.item(i);
                int ma = Integer.parseInt(el.getAttribute("maSach"));
                String ten = layTextTag(el, "tenSach");
                String loai = layTextTag(el, "theLoai");
                String nxb = layTextTag(el, "nhaXuatBan");
                double gia = Double.parseDouble(layTextTag(el, "giaBia"));
                boolean dangMuon = Boolean.parseBoolean(layTextTag(el, "dangMuon"));
                list.add(new Sach(ma, ten, loai, nxb, gia, dangMuon));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void luuDanhSachDocGia(List<DocGia> dsDocGia) {
        try {
            Document doc = taoDocumentMoi();
            Element root = doc.createElement("DanhSachDocGia");
            doc.appendChild(root);

            for (DocGia dg : dsDocGia) {
                Element node = doc.createElement("DocGia");
                node.setAttribute("maDocGia", String.valueOf(dg.getMaDocGia()));
                node.setAttribute("loaiDocGia", dg.getLoaiDocGia());
                node.appendChild(taoElementText(doc, "hoTen", dg.getHoTen()));
                node.appendChild(taoElementText(doc, "soCCCD", dg.getSoCCCD()));
                node.appendChild(taoElementText(doc, "soDienThoai", dg.getSoDienThoai()));
                node.appendChild(taoElementText(doc, "lopHoacDonVi", dg.getLopHoacDonVi()));
                root.appendChild(node);
            }
            ghiFileXml(doc, FILE_DOC_GIA);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<DocGia> docDanhSachDocGia() {
        List<DocGia> list = new ArrayList<>();
        File file = new File(FILE_DOC_GIA);
        if (!file.exists()) return list;
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
            doc.getDocumentElement().normalize();
            NodeList nodes = doc.getElementsByTagName("DocGia");
            for (int i = 0; i < nodes.getLength(); i++) {
                Element el = (Element) nodes.item(i);
                int ma = Integer.parseInt(el.getAttribute("maDocGia"));
                String loai = el.getAttribute("loaiDocGia");
                String hoTen = layTextTag(el, "hoTen");
                String cccd = layTextTag(el, "soCCCD");
                String sdt = layTextTag(el, "soDienThoai");
                String lop = layTextTag(el, "lopHoacDonVi");

                if ("Giáo viên".equalsIgnoreCase(loai)) {
                    list.add(new GiaoVien(ma, hoTen, cccd, sdt, lop));
                } else {
                    list.add(new HocSinh(ma, hoTen, cccd, sdt, lop));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void luuDanhSachPhieuMuon(List<PhieuMuon> dsPhieu) {
        try {
            Document doc = taoDocumentMoi();
            Element root = doc.createElement("DanhSachPhieuMuon");
            doc.appendChild(root);

            for (PhieuMuon pm : dsPhieu) {
                Element node = doc.createElement("PhieuMuon");
                node.setAttribute("maPhieu", String.valueOf(pm.getMaPhieu()));
                node.appendChild(taoElementText(doc, "maDocGia", String.valueOf(pm.getDocGia().getMaDocGia())));
                node.appendChild(taoElementText(doc, "maSach", String.valueOf(pm.getSach().getMaSach())));
                node.appendChild(taoElementText(doc, "ngayMuon", SDF.format(pm.getNgayMuon().getTime())));
                node.appendChild(taoElementText(doc, "hanTra", SDF.format(pm.getHanTra().getTime())));
                node.appendChild(taoElementText(doc, "ngayTra", pm.getNgayTra() != null ? SDF.format(pm.getNgayTra().getTime()) : ""));
                root.appendChild(node);
            }
            ghiFileXml(doc, FILE_PHIEU_MUON);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<PhieuMuon> docDanhSachPhieuMuon(List<DocGia> dsDocGia, List<Sach> dsSach) {
        List<PhieuMuon> list = new ArrayList<>();
        File file = new File(FILE_PHIEU_MUON);
        if (!file.exists()) return list;
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
            doc.getDocumentElement().normalize();
            NodeList nodes = doc.getElementsByTagName("PhieuMuon");
            for (int i = 0; i < nodes.getLength(); i++) {
                Element el = (Element) nodes.item(i);
                int maPhieu = Integer.parseInt(el.getAttribute("maPhieu"));
                int maDG = Integer.parseInt(layTextTag(el, "maDocGia"));
                int maSach = Integer.parseInt(layTextTag(el, "maSach"));

                DocGia dg = dsDocGia.stream().filter(d -> d.getMaDocGia() == maDG).findFirst().orElse(null);
                Sach sach = dsSach.stream().filter(s -> s.getMaSach() == maSach).findFirst().orElse(null);
                if (dg == null || sach == null) continue;

                Calendar calMuon = Calendar.getInstance();
                calMuon.setTime(SDF.parse(layTextTag(el, "ngayMuon")));

                Calendar calHan = Calendar.getInstance();
                calHan.setTime(SDF.parse(layTextTag(el, "hanTra")));

                String strTra = layTextTag(el, "ngayTra");
                Calendar calTra = null;
                if (!strTra.isEmpty()) {
                    calTra = Calendar.getInstance();
                    calTra.setTime(SDF.parse(strTra));
                }
                list.add(new PhieuMuon(maPhieu, dg, sach, calMuon, calHan, calTra));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean daCoDuLieuXml() {
        return new File(FILE_SACH).exists() || new File(FILE_DOC_GIA).exists();
    }

    public void xuatBaoCaoInHTML(File file, List<Sach> dsSach, List<PhieuMuon> dsPhieu,
                                 String thongKeTomTat) throws IOException {
        DecimalFormat df = new DecimalFormat("#,###");
        try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8))) {
            pw.println("<!DOCTYPE html><html lang='vi'><head><meta charset='UTF-8'>");
            pw.println("<title>Báo Cáo Thư Viện Trường Học</title>");
            pw.println("<style>body{font-family:Arial,sans-serif;margin:30px;} table{width:100%;border-collapse:collapse;margin-top:15px;}");
            pw.println("th,td{border:1px solid #444;padding:8px;text-align:left;} th{background:#f0f0f0;} .red{color:red;font-weight:bold;}</style></head><body>");
            pw.println("<h2>BÁO CÁO THỐNG KÊ HOẠT ĐỘNG THƯ VIỆN TRƯỜNG HỌC</h2>");
            pw.println("<p><strong>Ngày xuất báo cáo:</strong> " + SDF.format(Calendar.getInstance().getTime()) + "</p>");
            pw.println("<p>" + thongKeTomTat + "</p>");

            pw.println("<h3>Danh Sách Phiếu Mượn – Trả</h3><table>");
            pw.println("<tr><th>Mã Phiếu</th><th>Độc Giả</th><th>Đối Tượng</th><th>Sách Mượn</th><th>Ngày Mượn</th><th>Hạn Trả</th><th>Ngày Trả</th><th>Tiền Phạt</th><th>Trạng Thái</th></tr>");
            for (PhieuMuon pm : dsPhieu) {
                String ngayTra = pm.getNgayTra() != null ? SDF.format(pm.getNgayTra().getTime()) : "Chưa trả";
                String tt = pm.getNgayTra() != null ? "Đã trả" : (pm.isQuaHan() ? "<span class='red'>Quá hạn (" + pm.getSoNgayQuaHan() + " ngày)</span>" : "Đang mượn");
                pw.printf("<tr><td>%d</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s VNĐ</td><td>%s</td></tr>%n",
                        pm.getMaPhieu(), pm.getDocGia().getHoTen(), pm.getDocGia().getLoaiDocGia(),
                        pm.getSach().getTenSach(), SDF.format(pm.getNgayMuon().getTime()),
                        SDF.format(pm.getHanTra().getTime()), ngayTra, df.format(pm.getTienPhat()), tt);
            }
            pw.println("</table><script>window.onload=function(){window.print();}</script></body></html>");
        }
    }
}
