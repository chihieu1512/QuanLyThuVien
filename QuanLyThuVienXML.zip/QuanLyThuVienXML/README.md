# Phần Mềm Quản Lý Thư Viện Trường Học (CSDL XML)

## 1. Giới thiệu
Phần mềm Quản lý Thư viện Trường học được xây dựng bằng ngôn ngữ **Java (JDK 23)** trên môi trường **Apache NetBeans 23**, tổ chức theo kiến trúc phân tầng (`entity`, `dao`, `controller`, `view`) và lưu trữ toàn bộ cơ sở dữ liệu dưới định dạng **XML** (`data/sach.xml`, `data/docgia.xml`, `data/phieumuon.xml`).

## 2. Tài khoản đăng nhập hệ thống (Bắt buộc)
Phần mềm hỗ trợ đăng nhập và phân quyền 2 vai trò trước khi vào giao diện chính:
- **Tài khoản Quản trị viên (Toàn quyền Thêm, Sửa, Xóa):**
  - Tên đăng nhập: `admin`
  - Mật khẩu: `123456`
- **Tài khoản Nhân viên Thủ thư (Bị khóa nút Xóa dữ liệu):**
  - Tên đăng nhập: `thuthu`
  - Mật khẩu: `123456`

## 3. Các chức năng chính
- **Quản lý Sách & Độc giả (CRUD):** Thêm, sửa, xóa (có hộp thoại xác nhận), ID số nguyên tự động tăng, bắt lỗi trùng CCCD/Mã thẻ, lỗi nhập sai kiểu số hoặc bỏ trống trường bắt buộc.
- **Lập trình hướng đối tượng (OOP):** Áp dụng kế thừa (`Nguoi` -> `DocGia` -> `HocSinh`, `GiaoVien` và `TaiKhoan`), interface `IQuanLy<T>` và đa hình ghi đè phương thức tính hạn mượn & tiền phạt riêng cho Học sinh (mượn tối đa 7 ngày, phạt 5.000 VNĐ/ngày trễ) và Giáo viên (mượn tối đa 14 ngày, phạt 3.000 VNĐ/ngày trễ).
- **Quản lý Mượn – Trả:** Chọn ngày tháng năm bằng `Calendar` (`JSpinner`), tự động tính hạn trả, cảnh báo tự động theo ngày đối với phiếu quá hạn hoặc sắp đến hạn, tô màu phân biệt trên bảng `JTable`.
- **Tìm kiếm & Thống kê:** Tìm gần đúng theo chuỗi (không phân biệt hoa thường/dấu) và tìm theo khoảng số (khoảng giá bìa, khoảng tiền phạt); sắp xếp theo cột trên bảng; định dạng tiền tệ phân cách hàng nghìn (`1,000,000`); thống kê tổng số, lớn nhất (Max), nhỏ nhất (Min), tổng tiền kèm biểu đồ cột trực quan và xuất báo cáo in ấn (`.html`).

## 4. Hướng dẫn cài đặt, chạy và đóng gói chương trình
1. Cài đặt **JDK 23** và **Apache NetBeans 23**.
2. Giải nén thư mục `QuanLyThuVienXML`, mở NetBeans chọn **File -> Open Project...** và trỏ tới thư mục `QuanLyThuVienXML`.
3. Nhấn **Run Project (F6)** (hoặc chạy trực tiếp tệp `src/view/LoginFrame.java`).
4. **Đóng gói Executable Jar:** Chọn **Run -> Clean and Build Project (Shift + F11)**, tệp chạy `.jar` sẽ được xuất trong thư mục `target/` (hoặc `dist/`).
